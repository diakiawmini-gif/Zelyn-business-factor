import { useEffect, useRef, useState } from 'react';
import { Check, X, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';

const pricingPlans = [
  {
    name: 'Starter',
    description: 'Perfect for personal portfolios and small landing pages',
    monthlyPrice: 999,
    yearlyPrice: 799,
    popular: false,
    features: [
      { name: 'Single Page Website', included: true },
      { name: 'Mobile Responsive Design', included: true },
      { name: 'Basic SEO Setup', included: true },
      { name: 'Contact Form Integration', included: true },
      { name: '2 Revision Rounds', included: true },
      { name: 'Social Media Links', included: true },
      { name: 'E-commerce Functionality', included: false },
      { name: 'Custom Animations', included: false },
      { name: 'CMS Integration', included: false },
      { name: 'Priority Support', included: false },
    ],
    deliveryTime: '1-2 weeks',
  },
  {
    name: 'Business',
    description: 'Ideal for small businesses and professional services',
    monthlyPrice: 2499,
    yearlyPrice: 1999,
    popular: true,
    features: [
      { name: 'Up to 5 Pages', included: true },
      { name: 'Mobile Responsive Design', included: true },
      { name: 'Advanced SEO Setup', included: true },
      { name: 'Contact Form + Map', included: true },
      { name: 'Unlimited Revisions', included: true },
      { name: 'Social Media Integration', included: true },
      { name: 'Blog Setup', included: true },
      { name: 'Custom Animations', included: true },
      { name: 'E-commerce (up to 10 products)', included: false },
      { name: 'Priority Support', included: false },
    ],
    deliveryTime: '2-3 weeks',
  },
  {
    name: 'E-Commerce',
    description: 'Full-featured online store with all essentials',
    monthlyPrice: 3999,
    yearlyPrice: 3499,
    popular: false,
    features: [
      { name: 'Up to 10 Pages', included: true },
      { name: 'Mobile Responsive Design', included: true },
      { name: 'Complete SEO Package', included: true },
      { name: 'Payment Gateway Setup', included: true },
      { name: 'Unlimited Revisions', included: true },
      { name: 'Product Management', included: true },
      { name: 'Shopping Cart & Checkout', included: true },
      { name: 'Order Tracking System', included: true },
      { name: 'Inventory Management', included: true },
      { name: 'Priority Support (30 days)', included: true },
    ],
    deliveryTime: '3-4 weeks',
  },
  {
    name: 'Enterprise',
    description: 'Custom solutions for large-scale projects',
    monthlyPrice: null,
    yearlyPrice: null,
    popular: false,
    features: [
      { name: 'Unlimited Pages', included: true },
      { name: 'Custom Web Application', included: true },
      { name: 'Database Design', included: true },
      { name: 'User Authentication System', included: true },
      { name: 'API Development', included: true },
      { name: 'Third-party Integrations', included: true },
      { name: 'Admin Dashboard', included: true },
      { name: 'Analytics & Reporting', included: true },
      { name: 'Dedicated Support', included: true },
      { name: 'Maintenance Package', included: true },
    ],
    deliveryTime: 'Custom timeline',
  },
];

const addons = [
  { name: 'Additional Page', price: '$150' },
  { name: 'Blog Setup', price: '$300' },
  { name: 'Multilingual Support', price: '$400' },
  { name: 'Advanced Animations', price: '$250' },
  { name: 'Custom Illustrations', price: '$200' },
  { name: 'Speed Optimization', price: '$300' },
];

export function Pricing() {
  const [isYearly, setIsYearly] = useState(false);
  const [visibleCards, setVisibleCards] = useState<Set<number>>(new Set());
  const cardRefs = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          const index = Number(entry.target.getAttribute('data-index'));
          if (entry.isIntersecting) {
            setVisibleCards((prev) => new Set([...prev, index]));
          }
        });
      },
      { threshold: 0.2, rootMargin: '0px 0px -50px 0px' }
    );

    cardRefs.current.forEach((ref) => {
      if (ref) observer.observe(ref);
    });

    return () => observer.disconnect();
  }, []);

  return (
    <section id="pricing" className="py-24 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-background via-primary/5 to-background pointer-events-none" />
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-12">
          <span className="inline-block px-4 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
            Pricing
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-4">
            Transparent Pricing
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto mb-8">
            Choose the perfect package for your needs. All prices are one-time fees 
            with no hidden costs.
          </p>
          
          <div className="flex items-center justify-center gap-4">
            <span className={`text-sm ${!isYearly ? 'text-white' : 'text-muted-foreground'}`}>
              One-time Payment
            </span>
            <Switch
              checked={isYearly}
              onCheckedChange={setIsYearly}
            />
            <span className={`text-sm ${isYearly ? 'text-white' : 'text-muted-foreground'}`}>
              With Maintenance
              <span className="ml-2 text-xs text-primary">Save 20%</span>
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {pricingPlans.map((plan, index) => (
            <div
              key={plan.name}
              ref={(el) => { cardRefs.current[index] = el; }}
              data-index={index}
              className={`relative p-6 rounded-2xl transition-all duration-500 ${
                plan.popular
                  ? 'bg-gradient-to-b from-primary/20 to-card border-2 border-primary glow'
                  : 'bg-card border border-border hover:border-primary/30'
              } ${visibleCards.has(index) ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}
              style={{ transitionDelay: `${index * 100}ms` }}
            >
              {plan.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-primary text-white text-xs font-medium">
                    <Sparkles className="w-3 h-3" />
                    Most Popular
                  </span>
                </div>
              )}
              
              <div className="mb-4">
                <h3 className="text-xl font-semibold text-white mb-1">{plan.name}</h3>
                <p className="text-sm text-muted-foreground">{plan.description}</p>
              </div>
              
              <div className="mb-6">
                {plan.monthlyPrice ? (
                  <div className="flex items-baseline">
                    <span className="text-4xl font-bold text-white">
                      ${isYearly ? plan.yearlyPrice : plan.monthlyPrice}
                    </span>
                    <span className="text-muted-foreground ml-2">
                      {isYearly ? '/year' : ' one-time'}
                    </span>
                  </div>
                ) : (
                  <div className="text-2xl font-bold text-white">Custom Quote</div>
                )}
                <div className="text-sm text-muted-foreground mt-1">
                  Delivery: {plan.deliveryTime}
                </div>
              </div>
              
              <ul className="space-y-3 mb-6">
                {plan.features.map((feature) => (
                  <li key={feature.name} className="flex items-start gap-2">
                    {feature.included ? (
                      <Check className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                    ) : (
                      <X className="w-5 h-5 text-muted-foreground/50 flex-shrink-0 mt-0.5" />
                    )}
                    <span className={feature.included ? 'text-sm text-white' : 'text-sm text-muted-foreground/50'}>
                      {feature.name}
                    </span>
                  </li>
                ))}
              </ul>
              
              <Button
                className={`w-full ${
                  plan.popular
                    ? 'bg-primary hover:bg-primary/90 text-white'
                    : 'bg-secondary hover:bg-secondary/80 text-white'
                }`}
                onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
              >
                {plan.monthlyPrice ? 'Get Started' : 'Contact Me'}
              </Button>
            </div>
          ))}
        </div>

        <div className="bg-card border border-border rounded-2xl p-8">
          <h3 className="text-xl font-semibold text-white mb-6 text-center">
            Optional Add-ons
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {addons.map((addon) => (
              <div
                key={addon.name}
                className="text-center p-4 rounded-xl bg-secondary/50 hover:bg-secondary transition-colors"
              >
                <div className="text-primary font-semibold mb-1">{addon.price}</div>
                <div className="text-sm text-muted-foreground">{addon.name}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
