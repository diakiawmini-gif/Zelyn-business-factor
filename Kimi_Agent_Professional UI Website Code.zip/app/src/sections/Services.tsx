import { useEffect, useRef, useState } from 'react';
import { 
  ShoppingCart, 
  Building2, 
  Palette, 
  Code, 
  Smartphone, 
  Zap,
  ArrowRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';

const services = [
  {
    icon: Palette,
    title: 'Brand Websites',
    description: 'Stunning portfolio and brand showcase websites that make a lasting impression. Perfect for creatives, agencies, and professionals.',
    features: ['Custom Design', 'SEO Optimized', 'Mobile Responsive', 'Fast Loading'],
    color: 'from-pink-500 to-rose-500',
    price: 'From $999',
  },
  {
    icon: ShoppingCart,
    title: 'E-Commerce Stores',
    description: 'Full-featured online stores with secure payments, inventory management, and seamless checkout experiences.',
    features: ['Payment Integration', 'Product Management', 'Cart & Checkout', 'Order Tracking'],
    color: 'from-blue-500 to-cyan-500',
    price: 'From $2,499',
  },
  {
    icon: Building2,
    title: 'Business Websites',
    description: 'Professional corporate websites that establish credibility and drive conversions for your business.',
    features: ['Lead Generation', 'CRM Integration', 'Analytics', 'Multi-language'],
    color: 'from-violet-500 to-purple-500',
    price: 'From $1,499',
  },
  {
    icon: Code,
    title: 'Custom Web Apps',
    description: 'Tailored web applications with advanced functionality, dashboards, and user management systems.',
    features: ['User Authentication', 'Database Design', 'API Development', 'Cloud Deployment'],
    color: 'from-emerald-500 to-teal-500',
    price: 'From $3,999',
  },
  {
    icon: Smartphone,
    title: 'Responsive Design',
    description: 'Mobile-first approach ensuring your website looks perfect on every device and screen size.',
    features: ['Mobile Optimized', 'Cross-browser', 'Touch Friendly', 'Performance Tuned'],
    color: 'from-orange-500 to-amber-500',
    price: 'Included',
  },
  {
    icon: Zap,
    title: 'Performance Optimization',
    description: 'Speed up your existing website with advanced optimization techniques for better user experience.',
    features: ['Speed Audit', 'Code Optimization', 'CDN Setup', 'Caching Strategy'],
    color: 'from-yellow-500 to-lime-500',
    price: 'From $499',
  },
];

export function Services() {
  const [visibleCards, setVisibleCards] = useState<Set<number>>(new Set());
  const cardRefs = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          const index = Number(entry.target.getAttribute('data-index'));
          if (entry.isIntersecting) {
            setVisibleCards((prev) => new Set([...prev, index]));
          }
        });
      },
      { threshold: 0.2, rootMargin: '0px 0px -50px 0px' }
    );

    cardRefs.current.forEach((ref) => {
      if (ref) observer.observe(ref);
    });

    return () => observer.disconnect();
  }, []);

  return (
    <section id="services" className="py-24 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-background via-secondary/20 to-background pointer-events-none" />
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16">
          <span className="inline-block px-4 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
            Services
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-4">
            What I Can Build For You
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            From simple landing pages to complex web applications, I deliver 
            high-quality solutions tailored to your specific needs.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, index) => {
            const Icon = service.icon;
            const isVisible = visibleCards.has(index);
            
            return (
              <div
                key={service.title}
                ref={(el) => { cardRefs.current[index] = el; }}
                data-index={index}
                className={`group relative p-6 rounded-2xl bg-card border border-border hover:border-primary/50 transition-all duration-500 hover:glow ${
                  isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                }`}
                style={{ transitionDelay: `${index * 100}ms` }}
              >
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${service.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                
                <h3 className="text-xl font-semibold text-white mb-2">
                  {service.title}
                </h3>
                
                <p className="text-muted-foreground text-sm mb-4">
                  {service.description}
                </p>
                
                <ul className="space-y-2 mb-4">
                  {service.features.map((feature) => (
                    <li key={feature} className="flex items-center text-sm text-muted-foreground">
                      <div className={`w-1.5 h-1.5 rounded-full bg-gradient-to-r ${service.color} mr-2`} />
                      {feature}
                    </li>
                  ))}
                </ul>
                
                <div className="flex items-center justify-between mt-4 pt-4 border-t border-border">
                  <span className="text-lg font-semibold gradient-text">{service.price}</span>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    className="text-primary hover:text-primary hover:bg-primary/10 group/btn"
                    onClick={() => document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' })}
                  >
                    Get Quote
                    <ArrowRight className="ml-1 w-4 h-4 group-hover/btn:translate-x-1 transition-transform" />
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
