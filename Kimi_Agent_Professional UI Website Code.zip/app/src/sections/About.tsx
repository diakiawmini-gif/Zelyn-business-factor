import { useEffect, useRef, useState } from 'react';
import { 
  Code2, 
  Rocket, 
  Users, 
  Lightbulb,
  Award,
  Clock,
  Heart,
  Target
} from 'lucide-react';

const skills = [
  { name: 'React / Next.js', level: 95 },
  { name: 'TypeScript', level: 90 },
  { name: 'Node.js', level: 88 },
  { name: 'UI/UX Design', level: 85 },
  { name: 'Database Design', level: 82 },
  { name: 'DevOps / Cloud', level: 78 },
];

const values = [
  {
    icon: Rocket,
    title: 'Fast Delivery',
    description: 'I deliver projects on time without compromising on quality.',
  },
  {
    icon: Heart,
    title: 'Passionate',
    description: 'I genuinely love what I do and put my heart into every project.',
  },
  {
    icon: Target,
    title: 'Results-Driven',
    description: 'Focused on creating websites that achieve your business goals.',
  },
  {
    icon: Users,
    title: 'Collaborative',
    description: 'I work closely with clients to bring their vision to life.',
  },
];

const process = [
  {
    step: '01',
    icon: Lightbulb,
    title: 'Discovery',
    description: 'Understanding your goals, audience, and requirements through in-depth consultation.',
  },
  {
    step: '02',
    icon: Code2,
    title: 'Design & Development',
    description: 'Creating stunning designs and building robust, scalable solutions.',
  },
  {
    step: '03',
    icon: Rocket,
    title: 'Launch & Support',
    description: 'Deploying your website and providing ongoing maintenance and support.',
  },
];

export function About() {
  const [visibleElements, setVisibleElements] = useState<Set<string>>(new Set());
  const elementRefs = useRef<Map<string, HTMLDivElement>>(new Map());

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          const id = entry.target.getAttribute('data-id');
          if (id && entry.isIntersecting) {
            setVisibleElements((prev) => new Set([...prev, id]));
          }
        });
      },
      { threshold: 0.2, rootMargin: '0px 0px -50px 0px' }
    );

    elementRefs.current.forEach((el) => observer.observe(el));

    return () => observer.disconnect();
  }, []);

  const setRef = (id: string) => (el: HTMLDivElement | null) => {
    if (el) elementRefs.current.set(id, el);
  };

  return (
    <section id="about" className="py-24 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-background via-primary/5 to-background pointer-events-none" />
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center mb-24">
          <div
            ref={setRef('about-text')}
            data-id="about-text"
            className={`transition-all duration-700 ${
              visibleElements.has('about-text') ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-8'
            }`}
          >
            <span className="inline-block px-4 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
              About Me
            </span>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-6">
              Crafting Digital
              <span className="gradient-text"> Experiences</span>
            </h2>
            <p className="text-muted-foreground text-lg mb-6">
              I'm a passionate full-stack developer with over 3 years of experience 
              creating beautiful, functional websites and web applications. My journey 
              started with a curiosity for how things work on the web, and it has evolved 
              into a career dedicated to helping businesses succeed online.
            </p>
            <p className="text-muted-foreground text-lg mb-8">
              I specialize in modern web technologies and stay up-to-date with the latest 
              trends to deliver cutting-edge solutions. Every project is an opportunity 
              to create something amazing, and I approach each one with creativity, 
              precision, and dedication.
            </p>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Award className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <div className="text-white font-semibold">50+ Projects</div>
                  <div className="text-sm text-muted-foreground">Successfully delivered</div>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Clock className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <div className="text-white font-semibold">3+ Years</div>
                  <div className="text-sm text-muted-foreground">Industry experience</div>
                </div>
              </div>
            </div>
          </div>
          
          <div
            ref={setRef('skills')}
            data-id="skills"
            className={`transition-all duration-700 delay-200 ${
              visibleElements.has('skills') ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-8'
            }`}
          >
            <div className="bg-card border border-border rounded-2xl p-8">
              <h3 className="text-xl font-semibold text-white mb-6">Technical Skills</h3>
              <div className="space-y-5">
                {skills.map((skill) => (
                  <div key={skill.name}>
                    <div className="flex justify-between mb-2">
                      <span className="text-white text-sm">{skill.name}</span>
                      <span className="text-primary text-sm">{skill.level}%</span>
                    </div>
                    <div className="h-2 bg-secondary rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-primary to-purple-500 rounded-full transition-all duration-1000"
                        style={{ width: visibleElements.has('skills') ? `${skill.level}%` : '0%' }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="mb-24">
          <h3 className="text-2xl font-semibold text-white text-center mb-12">
            My Values
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((value, index) => {
              const Icon = value.icon;
              return (
                <div
                  key={value.title}
                  ref={setRef(`value-${index}`)}
                  data-id={`value-${index}`}
                  className={`p-6 rounded-2xl bg-card border border-border text-center transition-all duration-500 hover:border-primary/30 ${
                    visibleElements.has(`value-${index}`) ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                  }`}
                  style={{ transitionDelay: `${index * 100}ms` }}
                >
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                    <Icon className="w-6 h-6 text-primary" />
                  </div>
                  <h4 className="text-white font-semibold mb-2">{value.title}</h4>
                  <p className="text-muted-foreground text-sm">{value.description}</p>
                </div>
              );
            })}
          </div>
        </div>

        <div>
          <h3 className="text-2xl font-semibold text-white text-center mb-12">
            My Process
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {process.map((step, index) => {
              const Icon = step.icon;
              return (
                <div
                  key={step.title}
                  ref={setRef(`process-${index}`)}
                  data-id={`process-${index}`}
                  className={`relative transition-all duration-500 ${
                    visibleElements.has(`process-${index}`) ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
                  }`}
                  style={{ transitionDelay: `${index * 150}ms` }}
                >
                  <div className="text-6xl font-bold text-primary/10 absolute -top-4 -left-2">
                    {step.step}
                  </div>
                  <div className="relative pt-8">
                    <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-primary to-purple-500 flex items-center justify-center mb-4">
                      <Icon className="w-7 h-7 text-white" />
                    </div>
                    <h4 className="text-xl font-semibold text-white mb-2">{step.title}</h4>
                    <p className="text-muted-foreground">{step.description}</p>
                  </div>
                  {index < process.length - 1 && (
                    <div className="hidden md:block absolute top-1/2 -right-4 w-8 h-px bg-gradient-to-r from-primary to-transparent" />
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
