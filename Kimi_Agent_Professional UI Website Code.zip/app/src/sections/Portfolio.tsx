import { useEffect, useRef, useState } from 'react';
import { ExternalLink, Github, Eye } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';

const projects = [
  {
    id: 1,
    title: 'Luxe Fashion Store',
    category: 'E-Commerce',
    description: 'A premium fashion e-commerce platform with seamless shopping experience, advanced filtering, and secure checkout.',
    image: 'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=800&q=80',
    tags: ['React', 'Node.js', 'Stripe', 'MongoDB'],
    stats: { users: '10K+', sales: '$500K+', rating: '4.9' },
    color: 'from-pink-500 to-rose-500',
  },
  {
    id: 2,
    title: 'TechStart Agency',
    category: 'Business',
    description: 'Modern agency website with stunning animations, case studies, and lead generation forms.',
    image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&q=80',
    tags: ['Next.js', 'Framer Motion', 'Tailwind', 'Vercel'],
    stats: { leads: '300+', conversion: '12%', loadTime: '0.8s' },
    color: 'from-blue-500 to-cyan-500',
  },
  {
    id: 3,
    title: 'Artisan Coffee Brand',
    category: 'Brand',
    description: 'Elegant brand website showcasing artisan coffee products with rich storytelling and visual appeal.',
    image: 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=800&q=80',
    tags: ['Vue.js', 'GSAP', 'Shopify', 'Figma'],
    stats: { visitors: '50K+', engagement: '4:30', bounce: '25%' },
    color: 'from-amber-500 to-orange-500',
  },
  {
    id: 4,
    title: 'FitPro Dashboard',
    category: 'Web App',
    description: 'Comprehensive fitness tracking dashboard with workout plans, progress charts, and social features.',
    image: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=800&q=80',
    tags: ['React', 'TypeScript', 'D3.js', 'Firebase'],
    stats: { users: '25K+', workouts: '1M+', retention: '78%' },
    color: 'from-emerald-500 to-teal-500',
  },
  {
    id: 5,
    title: 'Architect Portfolio',
    category: 'Portfolio',
    description: 'Minimalist portfolio website for an architecture firm showcasing projects with immersive galleries.',
    image: 'https://images.unsplash.com/photo-1487958449943-2429e8be8625?w=800&q=80',
    tags: ['Next.js', 'Three.js', 'Prismic', 'AWS'],
    stats: { projects: '80+', awards: '12', inquiries: '200+' },
    color: 'from-violet-500 to-purple-500',
  },
  {
    id: 6,
    title: 'FoodDelivery Pro',
    category: 'E-Commerce',
    description: 'Full-featured food delivery platform with real-time tracking, reviews, and restaurant management.',
    image: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=800&q=80',
    tags: ['React Native', 'Node.js', 'Socket.io', 'PostgreSQL'],
    stats: { orders: '100K+', restaurants: '500+', rating: '4.8' },
    color: 'from-red-500 to-pink-500',
  },
];

const categories = ['All', 'E-Commerce', 'Business', 'Brand', 'Web App', 'Portfolio'];

export function Portfolio() {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedProject, setSelectedProject] = useState<typeof projects[0] | null>(null);
  const [visibleCards, setVisibleCards] = useState<Set<number>>(new Set());
  const cardRefs = useRef<(HTMLDivElement | null)[]>([]);

  const filteredProjects = selectedCategory === 'All'
    ? projects
    : projects.filter((p) => p.category === selectedCategory);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          const index = Number(entry.target.getAttribute('data-index'));
          if (entry.isIntersecting) {
            setVisibleCards((prev) => new Set([...prev, index]));
          }
        });
      },
      { threshold: 0.2, rootMargin: '0px 0px -50px 0px' }
    );

    cardRefs.current.forEach((ref) => {
      if (ref) observer.observe(ref);
    });

    return () => observer.disconnect();
  }, [filteredProjects]);

  return (
    <section id="portfolio" className="py-24 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-background via-secondary/10 to-background pointer-events-none" />
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-12">
          <span className="inline-block px-4 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
            Portfolio
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-4">
            Featured Projects
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            A selection of my recent work across various industries and project types.
          </p>
        </div>

        <div className="flex flex-wrap justify-center gap-2 mb-12">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                selectedCategory === category
                  ? 'bg-primary text-white'
                  : 'bg-secondary text-muted-foreground hover:text-white'
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProjects.map((project, index) => (
            <div
              key={project.id}
              ref={(el) => { cardRefs.current[index] = el; }}
              data-index={index}
              className={`group relative rounded-2xl overflow-hidden bg-card border border-border hover:border-primary/50 transition-all duration-500 hover:glow ${
                visibleCards.has(index) ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
              style={{ transitionDelay: `${index * 100}ms` }}
            >
              <div className="relative h-48 overflow-hidden">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-card via-card/50 to-transparent" />
                
                <div className="absolute top-4 left-4">
                  <Badge className={`bg-gradient-to-r ${project.color} text-white border-0`}>
                    {project.category}
                  </Badge>
                </div>
                
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/50">
                  <Button
                    variant="secondary"
                    size="sm"
                    className="mr-2"
                    onClick={() => setSelectedProject(project)}
                  >
                    <Eye className="w-4 h-4 mr-1" />
                    Details
                  </Button>
                  <Button variant="secondary" size="sm">
                    <ExternalLink className="w-4 h-4 mr-1" />
                    Live
                  </Button>
                </div>
              </div>
              
              <div className="p-6">
                <h3 className="text-xl font-semibold text-white mb-2 group-hover:text-primary transition-colors">
                  {project.title}
                </h3>
                <p className="text-muted-foreground text-sm mb-4 line-clamp-2">
                  {project.description}
                </p>
                <div className="flex flex-wrap gap-2">
                  {project.tags.map((tag) => (
                    <span
                      key={tag}
                      className="px-2 py-1 text-xs rounded-md bg-secondary text-muted-foreground"
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <Dialog open={!!selectedProject} onOpenChange={() => setSelectedProject(null)}>
        {selectedProject && (
          <DialogContent className="max-w-2xl bg-card border-border">
            <DialogHeader>
              <DialogTitle className="text-2xl text-white">{selectedProject.title}</DialogTitle>
              <DialogDescription className="text-muted-foreground">
                {selectedProject.category}
              </DialogDescription>
            </DialogHeader>
            
            <div className="mt-4">
              <img
                src={selectedProject.image}
                alt={selectedProject.title}
                className="w-full h-64 object-cover rounded-xl mb-6"
              />
              
              <p className="text-white mb-6">{selectedProject.description}</p>
              
              <div className="grid grid-cols-3 gap-4 mb-6">
                {Object.entries(selectedProject.stats).map(([key, value]) => (
                  <div key={key} className="text-center p-4 rounded-xl bg-secondary">
                    <div className="text-xl font-bold text-primary">{value}</div>
                    <div className="text-xs text-muted-foreground capitalize">{key}</div>
                  </div>
                ))}
              </div>
              
              <div className="flex flex-wrap gap-2 mb-6">
                {selectedProject.tags.map((tag) => (
                  <Badge key={tag} variant="secondary">
                    {tag}
                  </Badge>
                ))}
              </div>
              
              <div className="flex gap-3">
                <Button className="flex-1 bg-primary hover:bg-primary/90">
                  <ExternalLink className="w-4 h-4 mr-2" />
                  View Live Site
                </Button>
                <Button variant="outline" className="flex-1">
                  <Github className="w-4 h-4 mr-2" />
                  View Code
                </Button>
              </div>
            </div>
          </DialogContent>
        )}
      </Dialog>
    </section>
  );
}
